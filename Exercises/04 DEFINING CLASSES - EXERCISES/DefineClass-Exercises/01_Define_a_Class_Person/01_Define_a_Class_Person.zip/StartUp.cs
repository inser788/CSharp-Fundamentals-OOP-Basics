﻿    using System;

class StartUp
{
    public static void Main()
    {
        Person person=new Person();
        person.Name = "dasads";
        person.Age = 123;
    }
}

