﻿using System;

public class StartUp
{
    static void Main()
    {
        //var randomList = new RandomList();
        //randomList.Add("one");
        //randomList.Add("two");
        //randomList.Add("three");

        //Console.WriteLine(randomList.RandomString());
    }
}

