﻿public interface IBuyer
{
    int Food { get; }

    int BuyFood();
}

