﻿public interface IMember:IBuyer
{
    string Name { get; }
}

