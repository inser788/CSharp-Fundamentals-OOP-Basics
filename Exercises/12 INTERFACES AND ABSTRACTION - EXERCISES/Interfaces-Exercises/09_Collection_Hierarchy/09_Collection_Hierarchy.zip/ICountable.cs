﻿public interface ICountable : IRemovable
{
    int Used { get; }
}