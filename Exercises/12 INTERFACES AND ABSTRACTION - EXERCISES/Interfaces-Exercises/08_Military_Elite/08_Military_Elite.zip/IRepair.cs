﻿public interface IRepair
{
    string PartName { get; }
    int HoursWork { get; }
}

