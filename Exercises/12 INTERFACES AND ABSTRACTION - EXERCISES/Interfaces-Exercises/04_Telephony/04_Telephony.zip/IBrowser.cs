﻿public interface IBrowser
{
    string BrowseSite(string siteName);
}

