﻿public interface IPhonebook
{
    string Call(string phoneNumber);
}

