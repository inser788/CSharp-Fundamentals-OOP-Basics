﻿public interface IBirthdate
{
    string BirthDate { get; }
}

