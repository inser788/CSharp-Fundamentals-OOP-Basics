﻿public interface IElectricCar
{
    int Batterries { get; }
}

