﻿public class Engine
{
    private NationsBuilder nationBuilder;

    public Engine()
    {
        this.nationBuilder=new NationsBuilder();
    }

    public void Run()
    {

    }
}

