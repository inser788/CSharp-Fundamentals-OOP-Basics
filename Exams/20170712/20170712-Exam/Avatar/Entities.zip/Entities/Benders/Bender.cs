﻿public abstract class Bender
{
    public string Name { get; protected set; }

    public int  Power { get; protected set; }

    protected Bender(string name, int power)
    {
        Name = name;
        Power = power;
    }
}

