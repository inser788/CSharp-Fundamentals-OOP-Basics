﻿public abstract class Driver
{
    //Name – a string
    //    TotalTime – a floating-point number
    //Car - parameter of type Car
    //FuelConsumptionPerKm – a floating-point number
    //Speed – a floating-point number

  
    


    //RegisterDriver {type} {name} {hp} {fuelAmount} {tyreType} {tyreHardness}




}

