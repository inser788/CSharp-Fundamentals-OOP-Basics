﻿public class EnduranceDriver : Driver
{
}

