﻿using System;

public  class Car
{
    //Hp –  an integer
    //FuelAmount – a floating-point number
    //Tyre - parameter of type Tyre

    private int hp;
    private double fuelAmount;


    public int Hp => hp;
  
    public double FuelAmount
    {
        get => fuelAmount;
        set
        {
            if (value>160)
            {
                value = 160;
            }

            if (value<0)
            {
                throw new ArgumentException("Out of fuel");
            }

            this.fuelAmount = value;
        }
    }
}

